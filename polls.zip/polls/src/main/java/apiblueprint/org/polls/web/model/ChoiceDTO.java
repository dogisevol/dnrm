package apiblueprint.org.polls.web.model;


import apiblueprint.org.polls.domain.Choice;

public class ChoiceDTO {
    private String choice;
    private Integer votes;
    private Long id;

    public ChoiceDTO(Choice choice) {
        this.choice = choice.getChoice();
        this.votes = choice.getVotes();
    }
}

