package apiblueprint.org.polls.web.model;


import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;

import java.util.ArrayList;
import java.util.List;

public class PollModel {
    private String question;
    private Iterable<String> choices;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Iterable<String> getChoices() {
        return choices;
    }

    public void setChoices(Iterable<String> choices) {
        this.choices = choices;
    }

    public Poll toEntity() {
        Poll poll = new Poll();
        poll.setQuestion(this.question);
        List<Choice> choiceList = new ArrayList();
        for (String choiceText : choices) {
            Choice choice = new Choice();
            choice.setChoice(choiceText);
            choiceList.add(choice);
        }
        poll.setChoices(choiceList);
        return poll;
    }

}
