package apiblueprint.org.polls.web.model;


import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;

public class PollDTO {
    private final Long id;
    private String question;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T' HH:mm:ss.SSS'Z'")
    private ZonedDateTime publishedAt;
    private Collection<ChoiceDTO> choices = new ArrayList<>();

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public Iterable<ChoiceDTO> getChoices() {
        return choices;
    }

    public void setChoices(Collection<ChoiceDTO> choices) {
        this.choices = choices;
    }

    public PollDTO(Poll poll) {
        this.question = poll.getQuestion();
        this.id = poll.getId();
        this.publishedAt = poll.getPublishedAt();
        for (Choice choice : poll.getChoices()) {
            choices.add(new ChoiceDTO(choice));
        }
    }
}
