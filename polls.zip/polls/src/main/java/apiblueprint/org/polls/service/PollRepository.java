package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Poll;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

interface PollRepository extends CrudRepository<Poll, Long> {
    @Query(value = "SELECT p FROM Poll p LEFT JOIN FETCH p.choices")
    Iterable<Poll> fetchAll();
}
