package apiblueprint.org.polls.web;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import apiblueprint.org.polls.service.PollService;
import apiblueprint.org.polls.web.model.PollDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Controller
public class PollController {
    @Autowired
    private PollService pollService;

    @RequestMapping(value = "/questions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Transactional(readOnly = true)
    public Iterable<Poll> questions() {
        return pollService.fetchAll();
    }

    @RequestMapping(value = "/choices", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Transactional(readOnly = true)
    public Iterable<Choice> choices() {
        return pollService.fetchAllChoices();
    }

    @RequestMapping(value = "/questions", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    @Transactional
    public ResponseEntity<PollDTO> question(@RequestBody PollModel pollModel, UriComponentsBuilder b) {
        Poll poll = pollService.savePoll(pollModel.toEntity());
        UriComponents uriComponents =
                b.path("/questions/{id}").buildAndExpand(poll.getId());
        return  ResponseEntity.created(uriComponents.toUri()).body(new PollDTO(poll));
    }
}
