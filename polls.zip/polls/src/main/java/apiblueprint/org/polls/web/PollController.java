package apiblueprint.org.polls.web;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import apiblueprint.org.polls.service.PollService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PollController {
    @Autowired
    private PollService pollService;

    @RequestMapping(value = "/questions", method = RequestMethod.GET)
    @ResponseBody
    @Transactional(readOnly = true)
    public Iterable<Poll> questions() {
        return pollService.fetchAll();
    }

    @RequestMapping(value = "/choices", method = RequestMethod.GET)
    @ResponseBody
    @Transactional(readOnly = true)
    public Iterable<Choice> choices() {
        return pollService.fetchAllChoices();
    }

    @RequestMapping(value = "/questions", method = RequestMethod.POST)
    @ResponseBody
    @Transactional(readOnly = true)
    public Poll question(@ModelAttribute Poll poll) {
      return pollService.savePoll(poll);
    }
}
