package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("questionService")
@Transactional
public class PollServiceImpl implements PollService {

    private final PollRepository pollRepository;
    private final ChoiceRepository choiceRepository;

    public PollServiceImpl(PollRepository questionRepository, ChoiceRepository choiceRepository) {
        this.pollRepository = questionRepository;
        this.choiceRepository = choiceRepository;
    }

    @Override
    public Iterable<Poll> fetchAll() {
        return pollRepository.fetchAll();
    }

    @Override
    public Iterable<Choice> fetchAllChoices() {
        return choiceRepository.findAll();
    }

    @Override
    public Poll savePoll(Poll poll) {
        Poll result = pollRepository.save(poll);
        for (Choice choice : poll.getChoices()) {
            //choice.setPollId(result.getId());
            //choiceRepository.save(choice);
        }
        return result;
    }

}
