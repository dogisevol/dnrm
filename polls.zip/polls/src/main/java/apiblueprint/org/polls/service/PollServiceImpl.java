package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("questionService")
@Transactional
public class PollServiceImpl implements PollService {

    private final PollRepository questionRepository;
    private final ChoiceRepository choiceRepository;

    public PollServiceImpl(PollRepository questionRepository, ChoiceRepository choiceRepository) {
        this.questionRepository = questionRepository;
        this.choiceRepository = choiceRepository;
    }

    @Override
    public Iterable<Poll> fetchAll() {
        return questionRepository.fetchAll();
    }

    @Override
    public Iterable<Choice> fetchAllChoices() {
        return choiceRepository.findAll();
    }

    @Override
    public Poll savePoll(Poll poll) {
        return this.questionRepository.save(poll);
    }

}
