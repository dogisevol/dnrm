package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;

public interface PollService {
    Iterable<Poll> fetchAll();
    Iterable<Choice> fetchAllChoices();
    Poll savePoll(Poll poll);
}
