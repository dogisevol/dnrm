package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import org.springframework.transaction.annotation.Transactional;

public interface PollService {
    Iterable<Poll> fetchAll();
    Iterable<Choice> fetchAllChoices();
    @Transactional
    Poll savePoll(Poll poll);
}
