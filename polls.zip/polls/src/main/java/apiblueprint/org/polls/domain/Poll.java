package apiblueprint.org.polls.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Set;

@Entity
public class Poll implements Serializable{

    private static final long serialVersionUID = -3501514625217380338L;
    @Id
    @SequenceGenerator(name="question_generator", sequenceName="question_sequence", initialValue = 1)
    @GeneratedValue(generator = "question_generator")
    private Long id;

    @Column(nullable = false)
    private String question;

    @Column(nullable = false)
//    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T' HH:mm:ss.SSS'Z'")
    private ZonedDateTime publishedAt;

    @OneToMany(mappedBy = "poll", cascade = CascadeType.ALL)
    private Set<Choice> choices;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public ZonedDateTime getPublishedAt() {
        return publishedAt;
    }

    public void setPublishedAt(ZonedDateTime publishedAt) {
        this.publishedAt = publishedAt;
    }

    public Set<Choice> getChoices() {
        return choices;
    }

    public void setChoices(Set<Choice> choices) {
        this.choices = choices;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
