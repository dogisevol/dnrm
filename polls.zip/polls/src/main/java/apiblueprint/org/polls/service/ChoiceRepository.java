package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import apiblueprint.org.polls.domain.Poll;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;

interface ChoiceRepository extends CrudRepository<Choice, Long> {
}
