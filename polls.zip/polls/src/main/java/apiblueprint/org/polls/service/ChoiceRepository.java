package apiblueprint.org.polls.service;

import apiblueprint.org.polls.domain.Choice;
import org.springframework.data.repository.CrudRepository;

interface ChoiceRepository extends CrudRepository<Choice, Long> {
}
